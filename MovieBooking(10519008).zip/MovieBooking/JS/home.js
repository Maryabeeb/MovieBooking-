/* <!--Lawal,Maryam Adetoun with the cardNo 10519008-->*/

  $(function(){
    
    function openNav() {
    document.getElementById("mySidebar").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
  }
  
  /* Set the width of the sidebar to 0 and the left margin of the page content to 0 */
  function closeNav() {
    document.getElementById("mySidebar").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
  }

  $('.closebtn').on("click",function()
  {
    closeNav();
  })
  $('.openbtn').on("click",function()
  {
    openNav();
  })
    var myIndex = 0;
    carousel();
  
    function carousel() {
      var i;
      var x = document.getElementsByClassName("mySlides");
      var dots = document.getElementsByClassName("demo");
      for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
      }
      myIndex++;
      if (myIndex > x.length) { myIndex = 1 }
      x[myIndex - 1].style.display = "block";
      setTimeout(carousel, 3000);
    }
  })