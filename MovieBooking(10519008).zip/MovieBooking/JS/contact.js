//Lawal,Maryam Adetoun with the cardNo 10519008
$(function(){
    $('#btn').on("cllick",function(){
        saveName(($('#fn').text())+" "+($('#fn').text()));
        saveadd(($('#cemail').text()));
        $('#ex1').text("Thanks for the purchase," +localStorage.getItem("name"));
    })
    function saveName(detail){
        localStorage.setItem("name",detail);
    }
    function saveadd(detail){
        localStorage.setItem("MovieSelected",detail);
    }

})