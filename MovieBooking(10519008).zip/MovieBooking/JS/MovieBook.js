// LAWAL MARYAM ADETOUN, 10519008
$.getJSON('https://college-movies.herokuapp.com/', function (movies) {
    
    var htmlString = [];
    for (var i = 0; i < movies.length; i++) {
     
        var currentMovie = movies[i];
        //var movieC=currentMovie.title
        htmlString.push("<tr >");
        htmlString.push("<td id='myTd'  >");
        htmlString.push("<a id='clickableTD' href='#'onclick='getClicked()'>");

        if(currentMovie.title=="Geostorm"){
             htmlString.push("<img src='images/gs1.jpg'>");
            
        }
        else if(currentMovie.title=="The Jungle Book")
        {
            htmlString.push("<img src='images/tjb.jpg'>");
         }
         else if(currentMovie.title=="Dirty Grandpa")
         {
             htmlString.push("<img src='images/dirty.jpg'>");

          }
          else if(currentMovie.title=="Angry Birds")
          {
              htmlString.push("<img src='images/angry.jpg'>");

           }
           else if(currentMovie.title=="Finding Dory")
           {
               htmlString.push("<img src='images/fd.png'>");
              
            }
            else if(currentMovie.title=="Alice in Wonderland: Through the Looking Glass")
            {
                htmlString.push("<img src='images/alice.jpg'>");
             }
             
             else if(currentMovie.title=="Batman v Superman: Dawn of Justice")
            {
                htmlString.push("<img src='images/batman.jpg'>");
               
             }

             else if(currentMovie.title=="Kung Fu Panda 3")
            {
                htmlString.push("<img src='images/kungfu.jpg'>");

             }
             else if(currentMovie.title=="the Free State of Jones")
            {
                htmlString.push("<img src='images/StateofJones.png'>");
                
             }

             else if(currentMovie.title=="Zootopia")
            {
                htmlString.push("<img src='images/zoo.jpg'>");
               
             }
        htmlString.push(currentMovie.title);
       
        htmlString.push("</a>");
        htmlString.push("</td>");
        htmlString.push("</tr>");
    }

    var finalHTML = htmlString.join(" ")

    $('#bookinglist').append(finalHTML);
    
    
})

var movieClickedValue;

 function getClicked(){
var tbl = document.getElementById("tableList");
if (tbl != null) {
    for (var i = 0; i < tbl.rows.length; i++) {
        for (var j = 0; j < tbl.rows[i].cells.length; j++){
            tbl.rows[i].cells[j].onclick = function () { getval(this); };}
          
    } 
    
    
    }
function getval(name) {
    movieClickedValue=name.innerText;
    
   
    
    document.getElementById("text").innerText=movieClickedValue;
   var selectedMovie=name.innner;
    saveData(name.innerText);
    console.log(name.innerText);
   // console.log("this is transver"+document.getElementById("testing").innerHTML);

    $.getJSON('https://college-movies.herokuapp.com/', function (movies) {
    var htmlTimeString = [];
    for (var i = 0; i < movies.length; i++) {
     
       var Movietitle = $.trim(movieClickedValue);
       var mocount=movies[i]; var str="";
     
       if (movies[i].title == Movietitle){
        document.getElementById("year").innerHTML=movies[i].year;
        document.getElementById("director").innerHTML=movies[i].director;
        document.getElementById("cast").innerHTML=movies[i].cast;
        document.getElementById("genre").innerHTML=movies[i].genre;
        document.getElementById("notes").innerHTML=movies[i].notes;
        
        htmlTimeString.push("<tr class='tr1' id='timev'>");

        htmlTimeString.push("<td>");
        htmlTimeString.push("<td>");
        htmlTimeString.push("<h6>");
        htmlTimeString.push("Mon");
        htmlTimeString.push("</h>");
        htmlTimeString.push(generateSelect('MonTimes', 'Monday', movies[i].runningTimes.mon));
        htmlTimeString.push("</td>");

        htmlTimeString.push("<td>");
        htmlTimeString.push("<td>");
        htmlTimeString.push("<h6>");
        htmlTimeString.push("Tue");
        htmlTimeString.push("</h>");
        htmlTimeString.push(generateSelect('TueTimes', 'Tuesday', movies[i].runningTimes.tue));
        htmlTimeString.push("</td>");


        htmlTimeString.push("<td>");
        htmlTimeString.push("<h6>");
        htmlTimeString.push("WED");
        htmlTimeString.push("</h>");
        htmlTimeString.push(generateSelect('wedTimes', 'Wednesday', movies[i].runningTimes.wed));
        htmlTimeString.push("</td>");

        htmlTimeString.push("<td>");
        htmlTimeString.push("<td>");
        htmlTimeString.push("<h6>");
        htmlTimeString.push("Thu");
        htmlTimeString.push("</h>");
        htmlTimeString.push(generateSelect('thuTimes', 'Thursday', movies[i].runningTimes.thu));
        htmlTimeString.push("</td>");

        htmlTimeString.push("<td>");
        htmlTimeString.push("<td>");
        htmlTimeString.push("<h6>");
        htmlTimeString.push("Fri");
        htmlTimeString.push("</h>");
        htmlTimeString.push(generateSelect('friTimes', 'Friday', movies[i].runningTimes.fri));
        htmlTimeString.push("</td>");

        htmlTimeString.push("<td>");
        htmlTimeString.push("<td>");
        htmlTimeString.push("<h6>");
        htmlTimeString.push("Sat");
        htmlTimeString.push("</h>");
        htmlTimeString.push(generateSelect('satTimes', 'Saturday', movies[i].runningTimes.sat));
        htmlTimeString.push("</td>");

        htmlTimeString.push("<td>");
        htmlTimeString.push("<td>");
        htmlTimeString.push("<h6>");
        htmlTimeString.push("Sun");
        htmlTimeString.push("</h>");
        htmlTimeString.push(generateSelect('sunTimes', 'Sunday', movies[i].runningTimes.sun));
        htmlTimeString.push("</td>");
        htmlTimeString.push("</tr>");  

        var timeHTML = htmlTimeString.join("")
        if($('timeBody').val()==""){
                 $('#timeBody').append(timeHTML);
        }
        else{
        document.getElementById('timeBody').innerHTML="";
        
        console.log(document.getElementById('timeBody').innerHTML);
        $('#timeBody').append(timeHTML);
    }
       
        }
        else{
            console.log("false");
        }
   
   }
    
   $('#timeBody').on('change', '.movieTimes', function() {
 
    var element = $(this).prop('id');
    var currentTimeChosen = $(this).val();
    var currentDayChosen = $(this).data('day');
    console.log('movie time have changed for id: ' + element);
    console.log('movie time is set for : ' + currentTimeChosen);
    console.log('movie day is set for : ' + currentDayChosen);var dno=0;
    switch(currentDayChosen){
        
        case "Monday":
                dno=1;
                break;
        case "Tuesday":
            dno = 2;
            break;
        case "Wednesday":
            dno = 3;
            break;
            case "Thursday":
            dno=4;
            break;
        case "Friday":
            dno = 5;
            break;
        case "Saturday":
            dno = 6;
            break;
        case "Sunday":
            dno = 0;
            break;

    }

    var now = new Date(new Date().getFullYear(),new Date().getMonth() , new Date().getDate());    
    now.setDate(now.getDate() + (dno+(7-now.getDay())) % 7);
     console.log(now.toDateString());
    var dat=now.toDateString();
    savemTime(dat);
    $('#bookbtn').show();

    
})
    $('#detailID').show();
})


    }
 
}
//saving to local storage
    function saveData(detail){
        localStorage.setItem("MovieSelected",detail);
    }
    function savemTime(mt){
        localStorage.setItem("MovieTime",mt);
    }
    //selectionbox functions
    function generateSelect(id, day, items) {
 
        htmlString = [];
        htmlString.push(`<select id='${id}' data-day='${day}' class='movieTimes formcontrol'>`);
        htmlString.push("<option id='timing' value='Home.html'>Choose time</option");
     
        var options = items.map(x => {
     
            return `<option value='Home.html'>${x}</option>`;
     
        })
     
     
        htmlString.push(options.join(" "))
         htmlString.push("</select>");
     
        
        return htmlString.join(" ");
    }
    
